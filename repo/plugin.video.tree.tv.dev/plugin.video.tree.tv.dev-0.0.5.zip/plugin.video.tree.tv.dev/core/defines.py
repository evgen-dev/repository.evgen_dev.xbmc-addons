# -*- coding: utf-8 -*-

SITE_DOMAIN = 'tree.tv'
SITE_URL = 'http://'+SITE_DOMAIN
PLUGIN_ID = 'plugin.video.tree.tv.dev'
CACHE_DATABASE = 'treetv.cache.db'

SORT_TYPES = ['view', 'rate', 'new']