# -*- coding: utf-8 -*-

SITE_DOMAIN = 'tree.tv'
SITE_URL = 'http://'+SITE_DOMAIN
PLUGIN_ID = 'plugin.video.tree.tv.dev'

VIDEO_QUALITY = ['360', '480', '720', '1080']