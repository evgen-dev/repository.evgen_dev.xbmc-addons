# -*- coding: utf-8 -*-

import xbmcup.system

treetv = xbmcup.system.fs('home://addons/plugin.audio.lovifm/resources/media/icons/favorite.png')